from django.db import connections
from django.db.utils import OperationalError
from django.http.response import JsonResponse
from django.utils.timezone import localtime
import datetime
import dateutil.parser as dp

def get_pipeline_environments(request):
    """This api is used to get all environments"""
    try:
        cursor=connections['pipe'].cursor()
        query="""select distinct environment from pipeline.PipelineDetails"""
        cursor.execute(query)
        result = cursor.fetchall()
        return JsonResponse({'data': result,})
    except Exception as e:
        return JsonResponse({'error_msg': str(e),})
    
def get_pipeline_organizations(request):
    """This api is used to get all organizations"""
    try:
        environment = request.GET.get('environment','')
        cursor=connections['pipe'].cursor()
        query="""select distinct org from pipeline.PipelineDetails where environment='"""+environment+"""'"""
        cursor.execute(query)
        result = cursor.fetchall()
        return JsonResponse({'data': result,})
    except Exception as e:
        return JsonResponse({'error_msg': str(e),})
def get_all_details(request):
    """This api is used to get all details"""
    try:
        environment = request.GET.get('environment','')
        organization = request.GET.get('organization','')
        interval = request.GET.get('interval','')
        s = request.GET.get('start','')
        if interval == "today":
            start = datetime.datetime.strptime(s, "%Y-%m-%d %H:%M:%S")
            end = datetime.datetime.combine(start, datetime.datetime.min.time())
        elif interval == "yesterday":
            h=24
            ss = datetime.datetime.strptime(s, "%Y-%m-%d %H:%M:%S")
            start = datetime.datetime.combine(ss, datetime.datetime.min.time())
            e = start - datetime.timedelta(hours=h)
            end = e.strftime("%Y-%m-%d %H:%M:%S")
        elif interval == "4hours":
            start = datetime.datetime.strptime(s, "%Y-%m-%d %H:%M:%S")
            h=4
            e = start - datetime.timedelta(hours=h)
            end = e.strftime("%Y-%m-%d %H:%M:%S")
        else:
            h=168
            ss = datetime.datetime.strptime(s, "%Y-%m-%d %H:%M:%S")
            start = datetime.datetime.combine(ss, datetime.datetime.min.time())
            e = start - datetime.timedelta(hours=h)
            end = e.strftime("%Y-%m-%d %H:%M:%S")
        cursor=connections['pipe'].cursor()
        #query="""select * from pipeline.PipelineDetails where environment='"""+environment+"""' and ORG='"""+organization+"""'"""
        query="""SELECT t1.name,t1.srcid,t1.srcname,t1.srcstatus,t1.sinkid,t1.sinkname,t1.srcstatus as sinkstatus,t1.SourceType,t1.SinkType,COALESCE(t3.record_count, 0) SourceRecords,COALESCE(t3.size,0),COALESCE(t2.record_count, 0) SinkRecords,COALESCE(t2.size,0),COALESCE(t3.error_count,0) as SourceErrorCount,t3.last_ingested,COALESCE(t2.error_count,0) as SinkErrorCount,t2.last_written,t1.PUBID,t1.pubname,t1.pubstatus,t1.subid,t1.subname,t1.LastCollected
                 FROM pipeline.PipelineDetails as t1
                 LEFT JOIN metrics.file_sink_state as t2 
                 ON t1.SUBDatasetID = t2.data_set_id and t2.last_written >= '"""+str(end)+"""' and
                 t2.last_written <= '"""+str(start)+"""'
                 LEFT JOIN metrics.file_source_state as t3 
                 ON t1.SUBDatasetID = t3.data_set_id and t3.last_ingested >= '"""+str(end)+"""' and
                 t3.last_ingested <= '"""+str(start)+"""'
                 WHERE t1.Environment='"""+environment+"""' and t1.org='"""+organization+"""' and t1.PipeExist=True and t1.srcstatus='active' GROUP BY  t1.SRCID;"""
        print query
        cursor.execute(query)
        result = cursor.fetchall()
        return JsonResponse({'data': result,})
    except Exception as e:
        return JsonResponse({'error_msg': str(e),})
    

def get_instacart_data(request):
    """This api is used to get all organizations"""
    try:
        s = request.GET.get('start','')
        e = request.GET.get('end','')
        cid = request.GET.get('cid','')
        if cid == '24':
            h=24
            ss = datetime.datetime.strptime(s, "%Y-%m-%d %H:%M:%S")
            start = datetime.datetime.combine(ss, datetime.datetime.min.time())
            e = start - datetime.timedelta(hours=h)
            end = e.strftime("%Y-%m-%d %H:%M:%S")
        elif cid == '4':
            start = datetime.datetime.strptime(s, "%Y-%m-%d %H:%M:%S")
            h=4
            e = start - datetime.timedelta(hours=h)
            end = e.strftime("%Y-%m-%d %H:%M:%S")
        elif cid == '168':
            h=168
            ss = datetime.datetime.strptime(s, "%Y-%m-%d %H:%M:%S")
            start = datetime.datetime.combine(ss, datetime.datetime.min.time())
            e = start - datetime.timedelta(hours=h)
            end = e.strftime("%Y-%m-%d %H:%M:%S")
        elif cid == 'ctime':
            start = s
            end = e
        else:
            h = 0
            start = datetime.datetime.strptime(s, "%Y-%m-%d %H:%M:%S")
            end = datetime.datetime.combine(start, datetime.datetime.min.time())
        cursor=connections['pipe'].cursor()
        query="""SELECT t1.org,t1.name,t1.DatadogUrl,t1.SRCID SourceStatus,t1.sinkid SinkStatus,t1.srcstatus,t1.SourceType,t1.SinkType,COALESCE(t3.record_count, 0) SourceRecords,COALESCE(t2.record_count, 0) SinkRecords,COALESCE(t3.error_count,0) as SourceErrorCount,COALESCE(t2.error_count,0) as SinkErrorCount,t1.DatadogErrorUrl,t2.last_written SINKLastWritten,t2.error_message SINKLastErrorSeen,t3.last_ingested,t3.last_modified
                 FROM pipeline.PipelineDetails as t1
                 LEFT JOIN metrics.file_sink_state as t2 
                 ON t1.SUBDatasetID = t2.data_set_id and t2.last_written >= '"""+str(end)+"""' and
                 t2.last_written <= '"""+str(start)+"""'
                 LEFT JOIN metrics.file_source_state as t3 
                 ON t1.SUBDatasetID = t3.data_set_id and t3.last_ingested >= '"""+str(end)+"""' and
                 t3.last_ingested <= '"""+str(start)+"""'
                 WHERE t1.Environment='prod' and t1.org='instacart' and t1.PipeExist=True and t1.srcstatus='active' GROUP BY  t1.SRCID;"""
        cursor.execute(query)
        print query
        result = cursor.fetchall()
        lr = [list(x) for x in result]
        for i in lr:
            dt = i[13]
            if not dt:
                i.append("No time")
            else:
                seconds = int((datetime.datetime.utcnow() - dt).total_seconds())
                print seconds
                interval = seconds / (24 * 3600)
                txt=""
                if (interval > 0):
                    txt = str(interval) + "d "
                    seconds = seconds % (24 * 3600)

                interval = seconds / 3600
                if (interval > 0):
                    txt += str(interval) + "h "
                    seconds = seconds % 3600

                interval = seconds / 60
                txt += str(interval) + "m "

                i.append("(%s ago)"%txt)
        return JsonResponse({'data': lr,})
    except Exception as e:
        print e
        return JsonResponse({'error_msg': str(e),})             
    